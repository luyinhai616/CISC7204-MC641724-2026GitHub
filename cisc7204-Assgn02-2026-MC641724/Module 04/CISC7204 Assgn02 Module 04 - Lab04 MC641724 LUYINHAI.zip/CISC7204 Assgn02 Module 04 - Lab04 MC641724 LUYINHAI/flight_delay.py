import pandas as pd
import plotly.express as px
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output

airline_data = pd.read_csv('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv', 
                            encoding = "ISO-8859-1",
                            dtype={'Div1Airport': str, 'Div1TailNum': str, 
                                   'Div2Airport': str, 'Div2TailNum': str})

print(f"✅ Cloud data loaded successfully! Total rows: {len(airline_data)}")

airline_data['Year'] = pd.to_numeric(airline_data['Year'], errors='coerce')

app = dash.Dash(__name__)

app.layout = html.Div(children=[
    html.H1('Flight Details Statistics Dashboard', 
        style={'textAlign': 'center', 'color': '#503D36', 'font-size': 35}),
    
    html.Div([
        "Input Year: ",
        dcc.Input(id='input-year', value='2010', type='number', 
                  style={'height':'50px', 'font-size': 35}),
    ]),
    html.Br(),
    
    html.Div([
        html.Div(dcc.Graph(id='carrier-plot')),
        html.Div(dcc.Graph(id='weather-plot'))
    ], style={'display': 'flex'}),
    
    html.Div([
        html.Div(dcc.Graph(id='nas-plot')),
        html.Div(dcc.Graph(id='security-plot'))
    ], style={'display': 'flex'}),
    
    html.Div(dcc.Graph(id='late-plot'), style={'width': '65%'})
])


def compute_info(airline_data, entered_year):
    # Filter data for the specified year
    df = airline_data[airline_data['Year'] == int(entered_year)]
    
    if df.empty:
        print(f"⚠️ No data found for the year {entered_year}.")
        empty = pd.DataFrame(columns=['Month', 'Reporting_Airline', 'Value'])
        return empty, empty, empty, empty, empty

    def find_col(keyword):
        cols = [c for c in df.columns if keyword.lower() in c.lower()]
        return cols[0] if cols else None

    carrier_col = find_col('Carrier')
    weather_col = find_col('Weather')
    nas_col = find_col('NAS')
    security_col = find_col('Security')
    late_col = find_col('Late')

    def process_data(col_name):
        if col_name and col_name in df.columns:
            # If the delay column is found, compute the average
            return df.groupby(['Month', 'Reporting_Airline'])[col_name].mean().reset_index(name='Value')
        else:
            # If the delay column is not found, fallback to counting flight records
            return df.groupby(['Month', 'Reporting_Airline']).size().reset_index(name='Value')

    carrier_data = process_data(carrier_col)
    weather_data = process_data(weather_col)
    nas_data = process_data(nas_col)
    security_data = process_data(security_col)
    late_data = process_data(late_col)

    return carrier_data, weather_data, nas_data, security_data, late_data

@app.callback([
    Output(component_id='carrier-plot', component_property='figure'),
    Output(component_id='weather-plot', component_property='figure'),
    Output(component_id='nas-plot', component_property='figure'),
    Output(component_id='security-plot', component_property='figure'),
    Output(component_id='late-plot', component_property='figure')
],
[Input(component_id='input-year', component_property='value')])
def get_graph(entered_year):
    print(f"🚨 Callback triggered, input year: {entered_year}")
    
    # Compute required information for creating graphs
    carrier_data, weather_data, nas_data, security_data, late_data = compute_info(airline_data, entered_year)
    
    # Unified chart creation function for consistent styling
    def make_chart(data, title):
        if data.empty:
            return px.line(title=f"{title} - No Data")
        return px.line(data, x='Month', y='Value', title=title, color='Reporting_Airline')

    # Create the 5 charts
    carrier_fig = make_chart(carrier_data, 'Average carrier delay time (minutes) by airline')
    weather_fig = make_chart(weather_data, 'Average weather delay time (minutes) by airline')
    nas_fig = make_chart(nas_data, 'Average NAS delay time (minutes) by airline')
    security_fig = make_chart(security_data, 'Average security delay time (minutes) by airline')
    late_fig = make_chart(late_data, 'Average late aircraft delay time (minutes) by airline')
    
    return carrier_fig, weather_fig, nas_fig, security_fig, late_fig

if __name__ == '__main__':
    print("Starting the application...")
    app.run(debug=True)