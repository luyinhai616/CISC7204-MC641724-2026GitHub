# CISC7204 Assignment 02 Module 04 Lab 03

**Student ID:** mc641431
**Student Name:** WANGCUI

### **Project Description**
This project is for Module 04 Lab 03 Add Interactivity User Input and Callbacks.
It builds interactive web dashboards using Dash and Plotly based on the airline dataset.

### **Files in this folder**

1. dash_interactivity.py: Main task. A line chart dashboard showing month vs average flight delay time based on the input year.
2. dash_interactivity_barplot.py: Practice task. A bar chart dashboard showing flights to destination states by airline based on the input year.
3. airline_data.csv: The dataset used by the scripts.
4. requirements.txt: Required Python libraries.

###  **How to run**
**Step 1:** Install required packages
pip install -r requirements.txt

**Step 2:** Run the main dashboard
python dash_interactivity.py
Then open http://127.0.0.1:8050 in browser.

**Step 3:** Run the bar chart dashboard
python dash_interactivity_barplot.py
Then open http://127.0.0.1:8051 in browser.

**Notes**
Both scripts take year input and update the graphs with callback functions.
Tested and runs properly on local machine.
