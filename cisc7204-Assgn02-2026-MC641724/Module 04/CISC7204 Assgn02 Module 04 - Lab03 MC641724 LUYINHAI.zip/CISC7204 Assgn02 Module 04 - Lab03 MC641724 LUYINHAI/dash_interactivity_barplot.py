# Import required libraries
import pandas as pd
import plotly.express as px
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import os

# Read the airline data into the pandas dataframe (local file first, fallback to URL)
data_file = 'airline_data.csv' if os.path.exists('airline_data.csv') else 'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv'

airline_data = pd.read_csv(
    data_file,
    encoding="ISO-8859-1",
    dtype={
        'Div1Airport': str, 'Div1TailNum': str,
        'Div2Airport': str, 'Div2TailNum': str
    }
)

# Create a dash application
app = dash.Dash(__name__)

app.layout = html.Div(children=[
    html.H1(
        'Total number of flights to the destination state split by reporting airline',
        style={'textAlign': 'center', 'color': '#503D36', 'font-size': 40}
    ),
    html.Div([
        "Input Year: ",
        dcc.Input(
            id='input-year',
            value='2010',
            type='number',
            style={'height': '50px', 'font-size': 35}
        ),
    ], style={'font-size': 40}),
    html.Br(),
    html.Br(),
    html.Div(dcc.Graph(id='bar-plot')),
])

# Add Callback decorator
@app.callback(
    Output(component_id='bar-plot', component_property='figure'),
    Input(component_id='input-year', component_property='value')
)
def get_graph(entered_year):
    # Filter data for selected year
    df = airline_data[airline_data['Year'] == int(entered_year)]
    
    # Group the data by destination state and reporting airline, compute total number of flights
    bar_data = df.groupby(['DestState', 'Reporting_Airline'])['Flights'].sum().reset_index()
    
    # Create bar plot
    fig = px.bar(
        bar_data,
        x='DestState',
        y='Flights',
        color='Reporting_Airline',
        title=f'Total number of flights to the destination state split by reporting airline in {entered_year}'
    )
    fig.update_layout(
        title_font_size=20,
        xaxis_title='Destination State',
        yaxis_title='Flights'
    )
    return fig

# Run the app
if __name__ == '__main__':
    if hasattr(app, 'run'):
        app.run(port=8051)
    else:
        app.run_server(port=8051)

