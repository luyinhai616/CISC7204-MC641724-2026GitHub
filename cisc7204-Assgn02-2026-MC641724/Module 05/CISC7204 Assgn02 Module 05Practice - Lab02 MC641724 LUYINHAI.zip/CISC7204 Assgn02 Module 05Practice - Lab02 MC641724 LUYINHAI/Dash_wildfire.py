import pandas as pd
import dash
from dash import html, dcc
from dash.dependencies import Input, Output
import plotly.express as px

# Create app
app = dash.Dash(__name__)

# Clear the layout and do not display exceptions until callback gets executed
app.config.suppress_callback_exceptions = True

# Read the wildfire data into pandas dataframe
df = pd.read_csv('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/Historical_Wildfires.csv')

# Extract year and month from the date column (Automatically find the date column)
date_col = [col for col in df.columns if 'date' in col.lower()][0]
df['Month'] = pd.to_datetime(df[date_col]).dt.month_name()
df['Year'] = pd.to_datetime(df[date_col]).dt.year

# Layout Section of Dash
app.layout = html.Div(children=[
    html.H1("Australia Wildfire Dashboard", style={'textAlign': 'center', 'color': '#503D36', 'font-size': 26}),
    
    html.Div([
        # First inner division for adding radio items and dropdown
        html.Div([
            html.H2("Select Region:", style={'margin-right': '2em'}),
            dcc.RadioItems([
                {"label": "New South Wales", "value": "NSW"},
                {"label": "Northern Territory", "value": "NT"},
                {"label": "Queensland", "value": "QL"},
                {"label": "South Australia", "value": "SA"},
                {"label": "Tasmania", "value": "TA"},
                {"label": "Victoria", "value": "VI"},
                {"label": "Western Australia", "value": "WA"}
            ], 'NSW', id='region', inline=True),
            
            html.Div([
                html.H2("Select Year:", style={'margin-right': '2em'}),
                dcc.Dropdown(sorted(df.Year.unique()), value=2005, id='year')
            ])
        ]),
        
        # Second inner division for adding 2 inner divisions for 2 output graphs
        html.Div([
            html.Div([], id='plot1'),
            html.Div([], id='plot2')
        ], style={'display': 'flex'}),
    ])
])

# Callback function
@app.callback([
    Output(component_id='plot1', component_property='children'),
    Output(component_id='plot2', component_property='children')
],
[Input(component_id='region', component_property='value'),
 Input(component_id='year', component_property='value')])
def reg_year_display(input_region, input_year):
    try:
        # 1. Data selection
        region_col = [col for col in df.columns if 'region' in col.lower()][0]
        region_data = df[df[region_col] == input_region]
        y_r_data = region_data[region_data['Year'] == input_year]
        
        # If no data available for the selected criteria
        if y_r_data.empty:
            return html.Div("No data available for this selection."), html.Div("")

        # 2. Plot one - Monthly Average Estimated Fire Area
        # Automatically find column name for estimated fire area
        area_col = [col for col in df.columns if 'estimated' in col.lower() and 'area' in col.lower()][0]
        est_data = y_r_data.groupby('Month')[area_col].mean().reset_index()
        fig1 = px.pie(est_data, values=area_col, names='Month', 
                      title=f"Monthly Average Estimated Fire Area in {input_year} for {input_region}")
        
        # 3. Plot two - Monthly Average Count of Pixels for Presumed Vegetation Fires
        # Automatically find column name for count/pixels
        count_col = [col for col in df.columns if 'count' in col.lower() or 'pixel' in col.lower()][0]
        veg_data = y_r_data.groupby('Month')[count_col].mean().reset_index()
        fig2 = px.bar(veg_data, x='Month', y=count_col, 
                      title=f"Average Count of Pixels for Presumed Vegetation Fires in {input_year} for {input_region}")
        
        return [dcc.Graph(figure=fig1), dcc.Graph(figure=fig2)]
        
    except Exception as e:
        # Display error on the web page if something goes wrong
        print(f"❌ Error occurred: {e}")
        return html.Div(f"Error: {str(e)}"), html.Div("")

if __name__ == '__main__':
    app.run(debug=True)